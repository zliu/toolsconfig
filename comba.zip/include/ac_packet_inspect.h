#ifndef __AC_PACKET_INSPECT_H__
#define __AC_PACKET_INSPECT_H__

/** 
 * @brief 数据包预检，丢弃错包，正常包只返回UPD协议头偏移量
 * 
 * @param work
 * @param pinfo 用于指定数据包信息的结构体
 * 
 * @return 0，合法数据包
 *        -1，错误数据包
 */
inline int ac_packet_inspect(cvmx_wqe_t *work, packet_info_t *pinfo);
#endif
