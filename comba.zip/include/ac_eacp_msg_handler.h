#ifndef __ac_eacp_handler_h__
#define __ac_eacp_handler_h__

#include <ac_defs.h>
#include <ac_eacp_defs.h>

int ac_eacp_msg_wtp_add(void *payload, void *rspd, ac_forward_command_t *fwd_cmd);

inline void ac_eacp_msg_hdr_construct(void *pkt, void *rspd_pkt)
{
    memcpy(pkt, rspd_pkt + 6, 6);
    memcpy(pkt + 6, rspd_pkt, 6);
    *(rspd_pkt + 12) = 0x08;
    *(rspd_pkt + 13) = 0x00;
    ac_ip_header_t *ip_rqst_ptr = pkt + ipoffset;
    ac_ip_header_t *ip_ptr = rspd_pkt + ipoffset;
    ip_ptr->version = ip_rqst_ptr->version;
    ip_ptr->IHL = 0;//
    ip_ptr->TOS = 0;//
    ip_ptr->len = 0;
    ip_ptr->id = ip_rqst_ptr->id;
    ip_ptr->ip_flags = ip_rqst_ptr->ip_flags;
    ip_ptr->frag_offset = ip_rqst_ptr->frag_offset;
    ip_ptr->TTL = ip_rqst_ptr->TTL;
    ip_ptr->protocol = ip_rqst_ptr->protocol;
    ip_ptr->hdr_chksm = 0;
    ip_ptr->src = ip_rqst_ptr->dst;
    ip_ptr->dst = ip_rqst_ptr->src;
}

#endif
