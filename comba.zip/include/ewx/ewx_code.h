#ifndef __EWX_CODE_H__
#define __EWX_CODE_H__


enum {
	EWX_NO_SPACE_ERROR = 1000,
	EWX_PARAM_ERROR,
	EWX_NULL_POINTER,
	EWX_COMMON_ERROR,
};


enum {
	EWX_ITEM_NOT_FOUND = 2000,
};


#endif
