/** 
 * @brief 包转发模块,根据forward_command的内容进行包转发
 * 
 * @param forward_command 包转发command
 * 
 * @return 0, 发送成功; -1, 发送失败
 */
int ac_packet_forward(ac_forward_command_t *forward_command);
