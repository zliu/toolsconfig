#ifndef __AC_HASHTABLE_H__
#define __AC_HASHTABLE_H__
#include <ewx/ewx_hash_table.h>
#include <ac_defs.h>

ewx_hash_table_t *ac_ip_table_init(char *name, int bucket_num, int lock);
void *ac_ip_table_search(ewx_hash_table_t *iptable, ac_ip_table_item_t *item);
uint32_t ac_ip_table_insert(ewx_hash_table_t *iptable, ac_ip_table_item_t *item);
int32_t ac_ip_table_remove(ewx_hash_table_t *iptable, ac_ip_table_item_t *item);
void ac_ip_table_show(ewx_hash_table_t *iptable);
#endif
