#ifndef __AC_EACP_PROCESSOR_H__
#define __AC_EACP_PROCESSOR_H__

/** 
 * @brief EACP报文解析处理
 * 
 * @param work 收到的work
 * @param eacp_offset EACP协议头距离ip头的偏移量
 * @param respond 发送相应消息所需的信息，由本函数调用者提供，本函数内进行填充
 * 
 * @return 成功返回0
 */
int ac_eacp_processor(cvmx_wqe_t *work, uint8_t eacp_offset, ac_forward_command_t *respond);

#endif
