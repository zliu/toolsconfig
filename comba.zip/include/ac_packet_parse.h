#ifndef __AC_PACKET_PARSE_H_
#define __AC_PACKET_PARSE_H_

inline int ac_packet_parse(cvmx_wqe_t *work, packet_info_t *packet_info);

#endif
