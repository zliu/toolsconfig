#ifndef __AC_PACKET_PROCESS_H__
#define __AC_PACKET_PROCESS_H__
inline int ac_packet_process(cvmx_wqe_t *work, packet_info_t *packet_info, ac_forward_command_t *forward_cmd);
#endif
