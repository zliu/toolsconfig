#ifndef __EWX_BOARD_INIT_H__
#define __EWX_BOARD_INIT_H__
int ewx_board_init();
#endif
