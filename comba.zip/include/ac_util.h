#ifndef __AC_UTIL_H_
#define __AC_UTIL_H_

#define ac_external_ip_table_insert(ip) ac_config_external_ip_array_add(ip)
#define ac_external_ip_table_search(ip) ac_config_external_ip_array_search(ip)
#define ac_external_ip_table_remove(ip) ac_config_external_ip_array_del(ip)

#define IP_OFFSET_IN_WORK_PACKET_DATA 20

#define MAC_TO_U64(x) (((uint64_t)*(uint32_t *)x << 16) + (uint64_t)*(uint16_t*)((uint32_t *)x + 1))
#define IP_TO_U32(x) (*(uint32_t *)x)

inline void ac_swap_mac(void *src, void *dst);
inline void ac_copy_l2_hdr_with_vlan(void* src, void *dst, vlan_field);
inline void ac_copy_l2_hdr(void* src, void *dst);
inline void ac_copy_l2_hdr_with_vlan_swap_mac(void* src, void *dst, vlan_field);
inline void ac_copy_l2_hdr_swap_mac(void* src, void *dst);
inline void ac_swap_ip(void *ip_hdr);
inline void ac_copy_ip_hdr(void* src, void *dst);
inline void ac_copy_ip_hdr_swap_ip(void *src, void *dst);
#endif
