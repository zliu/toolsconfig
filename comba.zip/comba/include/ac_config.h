#ifndef __AC_SETUP_H_
#define __AC_SETUP_H_

#include <ac_type.h>

#define AC_DEFAULT_PARAMETER_INTERNAL_IP 0xC0A80001ul /* 192.168.0.1 */
#define AC_DEFAULT_PARAMETER_EXTERNAL_IP 0xC0A80002ul /* 192.168.0.2 */

ac_parameter_t g_ac_parameter;

#endif
