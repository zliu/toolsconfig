#ifndef __AC_TYPE_H_
#define __AC_TYPE_H_
/// 数据包信息数据结构
typedef struct packet_info_s packet_info_t;
struct packet_info_s {
    uint8_t     is_udp      : 1;    /**< 判定为UDP包置位 */     // set if software determined that packet is UDP 
    uint8_t     is_eacp     : 1;    /**< 判定为EACP包置位 */    // set if software determined taht packet is EACP
    uint8_t     is_capwap   : 1;    /**< 判定为CAPWAP包置位 */  // set if software determined taht packet is CAPWAP 
    uint8_t     reserved    : 5;    /**< 保留位 */              // reserved
    uint16_t    udp_offset;         /**< UDP header的偏移 */    // UDP header offset
    uint16_t    eacp_offset;        /**< EACP header的偏移 */   // EACP header offset
    uint16_t    capwap_offset;      /**< CAPWAP header的偏移 */ // CAPWAP header offset
    uint8_t     type;               /**< 包类型
                                     */
}

typedef struct ac_parameter_s {
    uint32_t internal_ip;
    ac_external_ip_table_t external_ip_table;
    ac_eacp_t eacp;
    ac_capwap_t capwap;
} ac_parameter_t;

#define AC_EXTERNAL_IP_ARRAY_SIZE 128

typedef struct ac_external_ip_table_s {
    uint8_t count;
    uint32_t table[AC_EXTERNAL_IP_ARRAY_SIZE];
} ac_external_ip_table_t;

typedef struct ac_eacp_s {
    uint16_t sport;
    uint16_t dport;
} ac_eacp_t;

typedef struct ac_capwap_s {
    uint16_t data_sport;
    uint16_t data_dport;
    uint16_t ctrl_sport;
    uint16_t ctrl_dport;
} ac_capwap_t;

typedef enum {
    icmp    = 1;
    igmp    = 2;
    tcp     = 6;
    igrp    = 9;
    udp     = 17;
    gre     = 47;
    esp     = 50;
    ah      = 51;
} l4_protocol_t;

typedef struct ac_arp_header_s {
    uint32_t hw_type : 16;
    uint32_t proto_type : 16;
    uint32_t hw_size : 8;
    uint32_t proto_size : 8;
    uint32_t opcode : 16;
} ac_arp_header_t;

typedef struct ac_capwap_header_s {
    uint32_t preamble : 8;
    uint32_t hlen : 5;
    uint32_t rid : 5;
    uint32_t wid : 5;
    uint32_t t : 1;
    uint32_t f : 1;
    uint32_t l : 1;
    uint32_t w : 1;
    uint32_t m : 1;
    uint32_t k : 1;
    uint32_t flags : 3;
    uint32_t flagment_id : 16;
    uint32_t flagment_offset : 13;
    uint32_t reversed : 3;
} ac_capwap_header_t;

typedef struct ac_ip_header_s {
    uint32_t    version : 4;
    uint32_t    IHL : 4;
    uint32_t    TOS : 8; 
    uint32_t    len : 16;
    uint32_t    id : 8;
    uint32_t    ip_flags: 3;
    uint32_t    frag_offset: 13;
    uint32_t    TTL : 8;
    uint32_t    protocol : 8;
    uint32_t    hdr_chksm : 36;
    uint32_t    src;
    uint32_t    dst;
} ac_ip_header_t;
#endif
