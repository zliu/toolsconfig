#ifndef __AC_UTIL_H_
#define __AC_UTIL_H_

#define ac_external_ip_table_insert(ip) ac_config_external_ip_array_add(ip)
#define ac_external_ip_table_search(ip) ac_config_external_ip_array_search(ip)
#define ac_external_ip_table_remove(ip) ac_config_external_ip_array_del(ip)

#endif
