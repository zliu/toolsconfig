#ifndef __AC_COMMON_DEFS_H_
#define __AC_COMMON_DEFS_H_

#endif
