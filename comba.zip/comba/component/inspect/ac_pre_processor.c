/** 
 * @file ac_pre_processor.c
 * @brief preprocess: inspect a packet, determine if it's UDP packet and calculate UDP offset
 * @author Zhuo Liu
 * @version 0.0.1
 * @date 2010-05-04
 */
#include <stdio.h>
#include <ac_type.h>
#include <cvmx-wqe.h>
#include <octeon-feature.h>
#include "ac_pre_processor.h"
inline int ac_packet_inspector(cvmx_wqe_t *work, packet_info_t *pinfo)
{
    const int use_ipd_no_wptr = octeon_has_feature(OCTEON_FEATURE_NO_WPTR);
    if (cvmx_unlikely(work->word2.snoip.rcv_error) && (work->word2.snoip.err_code != CVMX_PIP_OVER_ERR)) { /* receive error, return err code */
        cvmx_helper_free_packet_data(work);
        if (use_ipd_no_wptr)
            cvmx_fpa_free(work, CVMX_FPA_PACKET_POOL, 0);
        else
            cvmx_fpa_free(work, CVMX_FPA_WQE_POOL, 0);
        return -1;
    }
    if (!work->word2.s.not_IP && work->word2.s.tcp_or_udp) { /* TCP or UDP packet */
        ac_ip_header_t *ip_head = (ac_ip_header_t *)work->packet_data;
        if (ip_head->protocal == l4_protocol.udp) { /* UDP packet, return packet type and offset */
            pinfo->is_upd = 1;
            pinfo->udp_offset = ip_head->IHL * 4 + work->word2.s.ip_offset; /* calculate offset and convert into bytes */
        } else { /* TCP packet, return packet type*/
            pinfo->is_upd = 0;
        }
    }
    return 0;
}
