#include <stdio.h>
#include <cvmx-wqe.h>

typedef enum {
    icmp    = 1;
    igmp    = 2;
    tcp     = 6;
    igrp    = 9;
    udp     = 17;
    gre     = 47;
    esp     = 50;
    ah      = 51;
} l4_protocol;

typedef struct ac_ip_header_s {
    uint8_t     version: 4;
    uint8_t     IHL: 4;
    uint8_t     TOS; 
    uint16_t    length;
    uint16_t    id;
    uint16_t    ip_flags: 3;
    uint16_t    frag_offset: 13;
    uint8_t     TTL;
    uint8_t     protocol;
    uint16_t    header_chksm;
    uint32_t    src;
    uint32_t    dst;
} ac_ip_header_t;

inline int ac_packet_inspector(cvmx_wqe_t *work, int *udp_offset)
{
    if (work->word2.s.rcv_error) {
        return work->word2.s.err_code;
    }
    if (work->word2.s.not_IP) {
        if (work->word2.snoip.is_arp) {
            ;
        } else {
            return 0;
        }
    } else {
        if (work->word2.s.IP_exc) {
            return work->word2.s.err_code;
        } else if (!work->word2.s.is_frag && work->word2.s.L4_error) {
            return work->word2.s.err_code;
        }
        if (work->word2.s.tcp_or_udp) {
            ac_ip_header_t *ip_head = (ac_ip_header_t *)work->packet_data;
            if (ip_head->protocal == l4_protocol.udp) {
                *udp_offset = ip_head->IHL * 4;
                return 0;
            } else {
                return 0;
            }
        } else {
            return 1;
        }
    return 0;
}
