#ifndef __AC_PACKET_PARSE_H_
#define __AC_PACKET_PARSE_H_

#define L2_OFFSET_IN_WORK_PACKET_DATA 6

#endif
