#include <ac_util.h>
int ac_packet_parse(cvmx_wqe_t *work, packet_info_t *packet_info) 
{
    uint32_t dip;
    if (!work->word2.s.not_IP) { /* IP */
        dip = *(uint32_t *)&work->packet_data[L2_OFFSET_IN_WORK_PACKET_DATA + work->word2.s.ip_offset + 16]; // need check
        printf("dip = %lu\n", dip);
        if (dip == g_ac_parameter.internal_ip) { /* From Linux */
            if (packet_info->is_udp) { /* UDP */
                sport = *(uint16_t *)&work->packet_data[L2_OFFSET_IN_WORK_PACKET_DATA + packet_info->udp_offset];
                dport = *(uint16_t *)&work->packet_data[L2_OFFSET_IN_WORK_PACKET_DATA + packet_info->udp_offset + 2];
                printf("sport = %lu\n", sport);
                printf("dport = %lu\n", dport);
                if ((dport == g_ac_parameter.eacp.dport) && (sport == g_ac_parameter.eacp.sport)) { /* EACP */

                } else { /* Submit to Linux */
                    
                }
            } else { /* not UDP packet -> Submit to Linux */

            }
        } else if (ac_external_ip_table_search(dip) == 1) { /* To AC */
            if (packet_info->is_udp) { /* UDP */
                sport = *(uint16_t *)&work->packet_data[L2_OFFSET_IN_WORK_PACKET_DATA + packet_info->udp_offset];
                dport = *(uint16_t *)&work->packet_data[L2_OFFSET_IN_WORK_PACKET_DATA + packet_info->udp_offset + 2];
                printf("sport = %lu\n", sport);
                printf("dport = %lu\n", dport);
                if (dport == g_ac_parameter.capwap.ctrl_dport) { // EACP Control Packet -> Submit to Linux

                } else if (dport = g_ac_parameter.capwap.data_dport) { 

                }(sport == g_ac_parameter.capwap.ctrl_sport)) { /* EACP */

                } else { /* Submit to Linux */
                    
                }
            } else { /* not UDP packet -> Submit to Linux */

            }
           
        }
    } else if (work->word2.s.is_arp) { /* ARP */
        dip = (uint32_t)(work)
    } else { /* unknown L2 packet */
    }
    return 0;
}
