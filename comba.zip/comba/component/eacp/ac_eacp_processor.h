#ifndef __AC_CACP_PROCESSOR_H__
#define __AC_CACP_PROCESSOR_H__
#include <mleacpcmd.h>
/** 
 * @brief EACP帧格式中class字段定义
 */
/* #define EACP_MSG_C_BASIC_CONTROL (BASIC_CMD_CLS >> 8)    [> 基本控制消息。如WTP信息，STA信息，AC地址等 <] */
/* #define EACP_MSG_C_ACL (ACL_CMD_CLS >> 8)    [> ACL相关消息 <] */
/* #define EACP_MSG_C_QOS (QOS_CMD_CLS >> 8)    [> QoS相关消息 <] */
/* #define EACP_MSG_C_TC (TC_CMD_CLS >> 8)    [> 流量控制相关消息 <] */
/* #define EACP_MSG_C_ALARM_CFG (ALARM_SET_CMD_CLS >> 8)    [> 告警设置消息 <] */
/* [> 0x05-0x1f    [> 预留做其它控制类消息 <] <] */
/* #define EACP_MSG_C_STAT (STAT_CMD_CLS >> 8)   [> 统计信息 <] */
/* #define EACP_MSG_C_ALARM (ALARM_MSG_CLS >> 8)    [> 告警类消息 <] */
#define AC_EACP_MSG_TYPE(m) (m >> 8)
/** 
 * @brief EACP帧格式中type字段定义
 */
#define EACP_MSG_T_DPLANE_RST RESET_DATAPLANE_CMD  /* 复位数据面 */ 
/* #define EACP_MSG_T_DPLANE_RST_RSPD (EACP_MSG_T_DPLANE_RST_RSPD |0x80)  [> 复位数据面响应 <]  */
#define EACP_MSG_T_ACIPMAC_ADD ADD_AC_IP_MAC_CMD /* 添加AC的IP及MAC */ 
/* #define EACP_MSG_T_ACIP_ADD_RSPD 0x0082 [> 添加AC的IP及MAC响应 <]  */
#define EACP_MSG_T_ACIPMAC_DEL DEL_AC_IP_MAC_CMD /* 删除AC的IP及MAC */ 
/* #define 0x0083 [> 删除AC的IP及MAC响应 <]  */
#define EACP_MSG_T_ACIPMAC_SEARCH QUERY_AC_IP_MAC_CMD /* 查询AC的IP及MAC */ 
/* #define 0x0084 [> 查询AC的IP及MAC响应 <]  */
#define EACP_MSG_T_CAPWAP_PORT_SET SET_CAPWAP_PORT_CMD /* 设置CAPWAP端口 */ 
/* #define 0x0085 [> 设置CAPWAP端口响应 <]  */
#define EACP_MSG_T_CAPWAP_PORT_GET QUERY_CAPWAP_PORT_CMD /* 查询CAPWAP端口 */ 
/* #define 0x0086 [> 查询CAPWAP端口响应 <]  */
#define EACP_MSG_T_JUMBO_SWITCH SET_JUMBO_CMD /* 设置Jumbo开关 */ 
/* #define 0x0087 [> 设置Jumbo开关响应 <]  */
#define EACP_MSG_T_WTP_ADD ADD_WTP_CMD /* 添加更新WTP信息 */ 
/* #define 0x0088 [> 添加更新WTP信息响应 <]  */
#define EACP_MSG_T_WTP_DEL DEL_SPECIFIED_WTP_CMD  /* 删除指定WTP信息 */ 
/* #define 0x0089 [> 删除指定WTP信息响应 <]  */
#define EACP_MSG_T_WTP_DEL_ALL DEL_ALL_WTP_CMD /* 删除全部WTP信息 */ 
/* #define 0x008a [> 删除全部WTP信息响应 <]  */
#define EACP_MSG_T_WTP_SEARCH_ALL QUERY_ALL_WTP_CMD /* 查询全部WTP信息 */ 
/* #define 0x008b [> 查询全部WTP信息响应 <]  */
#define EACP_MSG_T_WTP_SEARCH_RANGE QUERY_SECTION_WTP_CMD /* 查询某一段WTP信息 */ 
/* #define 0x008c [> 查询某一段WTP信息响应 <]  */
#define EACP_MSG_T_WTP_SEARCH QUERY_SPECIFIED_WTP_CMD /* 查询指定WTP信息 */
/* #define 0x008d [> 查询指定WTP信息响应 <] */
#define EACP_MSG_T_STA_ADD ADD_STA_CMD /* 添加更新STA信息 */
/* #define 0x008e [> 添加更新STA信息响应 <] */
#define EACP_MSG_T_STA_DEL DEL_SPECIFIED_STA_CMD /* 删除指定STA信息 */
/* #define 0x008f [> 删除指定STA信息响应 <] */
#define EACP_MSG_T_STA_DEL_ALL DEL_ALL_STA_CMD /* 删除全部STA信息 */
/* #define 0x0090 [> 删除全部STA信息响应 <] */
#define EACP_MSG_T_STA_SEARCH_ALL QUERY_ALL_STA_CMD /* 查询全部STA信息 */
/* #define 0x0091 [> 查询全部STA信息响应 <] */
#define EACP_MSG_T_STA_SEARCH_RANGE QUERY_SECTION_STA_CMD /* 查询某一段STA信息 */
/* #define 0x0092 [> 查询某一段STA信息响应 <] */
#define EACP_MSG_T_STA_SEARCH QUERY_SPECIFIED_STA_CMD /* 查询指定STA信息 */
/* #define 0x0093 [> 查询指定STA信息响应 <] */
/*
 * ACL相关消息类
 */
#define EACP_MSG_T_ACL_WTP_ADD ADD_WTP_ACL_CMD /* 添加更新WTP的ACL */
/* #define 0x0181 [> 添加更新WTP的ACL响应 <] */
#define EACP_MSG_T_ACL_WTP_DEL_ALL DEL_ALL_WTP_ACL_CMD /* 删除全部WTP的ACL */
/* #define 0x0182 [> 删除全部WTP的ACL响应 <] */
#define EACP_MSG_T_ACL_WTP_DEL DEL_SPECIFIED_WTP_ACL_CMD /* 删除ACL中指定WTP */
/* #define 0x0183 [> 删除ACL中指定WTP响应 <] */
#define EACP_MSG_T_ACL_WTP_SEARCH_ALL QUERY_ALL_WTP_ACL_CMD /* 查询全部WTP的ACL */
/* #define 0x0184 [> 查询全部WTP的ACL响应 <] */
#define EACP_MSG_T_ACL_WTP_SEARCH_RANGE QUERY_SECTION_WTP_ACL_CMD /* 查询某一段WTP的ACL */
/* #define 0x0185 [> 查询某一段WTP的ACL响应 <] */
#define EACP_MSG_T_ACL_WTP_SEARCH QUERY_SPECIFIED_WTP_ACL_CMD /* 查询ACL中部分指定WTP的信息 */
/* #define 0x0186 [> 查询ACL中部分指定WTP的信息响应 <] */
#define EACP_MSG_T_ACL_STA_ADD ADD_STA_ACL_CMD /* 添加更新STA的ACL */
/* #define 0x0187 [> 添加更新STA的ACL响应 <] */
#define EACP_MSG_T_ACL_STA_DEL_ALL DEL_ALL_STA_ACL_CMD /* 删除全部STA的ACL */
/* #define 0x0188 [> 删除全部STA的ACL响应 <] */
#define EACP_MSG_T_ACL_STA_DEL DEL_SPECIFIED_STA_ACL_CMD /* 删除ACL中指定STA */
/* #define 0x0189 [> 删除ACL中指定STA响应 <] */
#define EACP_MSG_T_ACL_STA_SEARCH_ALL QUERY_ALL_STA_ACL_CMD /* 查询全部STA的ACL */
/* #define EACP_MSG_T_ACL_STA_SEARCH_ALL QUERY_ALL_STA_ACL_CMD [> 查询全部STA的ACL <] */
#define EACP_MSG_T_ACL_STA_SEARCH_RANGE QUERY_SECTION_STA_ACL_CMDA /* 查询某一段STA的ACL */
/* #define EACP_MSG_T_ACL_STA_SEARCH_RANGE QUERY_SECTION_STA_ACL_CMDA [> 查询某一段STA的ACL <] */
#define EACP_MSG_T_ACL_STA_SEARCH_ALL QUERY_SPECIFIED_STA_ACL_CMD /* 查询ACL中部分指定的STA */
/* #define EACP_MSG_T_ACL_STA_SEARCH_ALL QUERY_SPECIFIED_STA_ACL_CMD [> 查询ACL中部分指定的STA <] */
/*
 * QoS相关消息类
 */
/*
 * TC相关消息类
 */
/*
 * 告警设置消息类
 */
#define EACP_MSG_T_ALARM_CPU_THRESHOLD_SET SET_CPU_ALARM_LEVEL_CMD /* 设置CPU告警门限 */

/*
 * 统计相关消息类 
 */
#define EACP_MSG_T_STAT_DPLANE_UPTIME_GET GET_DATAPLANE_RUN_TIME_CMD /* 获取数据面运行时间 */
#define EACP_MSG_T_STAT_CPU_USAGE_GET GET_DATAPLANE_CPU_USAGE_CMD /* 获取数据面CPU平均利用率 */
#define EACP_MSG_T_STAT_PACKETS_COUNTERS_GET GET_DATAPLANE_PACKETS_STAT_CMD /* 获取数据面数据包统计信息 */

/*
 * 告警消息类 
 */
#define EACP_MSG_T_REPORT_CPU_OVERHEAD DATAPLANE_CPU_USAGE_ALARM /* 告警消息：CPU利用率过高 */
#define EACP_MSG_T_REPORT_CPU_NORMAL DATAPLANE_CPU_USAGE_ALARM_CLEAR /* 清除告警：CPU利用率正常 */

typedef struct msgHdr ac_eacp_msg_hdr_t;
typedef struct EACP_HDR ac_eacp_hdr_t;

typedef struct ac_eacp_header_s {
    uint32_t    preamble;
    uint32_t    sequence;
    uint32_t    msg_class : 8;
    uint32_t    A : 1;
    uint32_t    msg_type : 7;
    uint32_t    len : 16;
    struct payload_t payload;
} ac_eacp_header_t;
int ac_eacp_processor(cvmx_wqe_t *work, uint8_t eacp_offset, ac_eacp_header_t *respond);
int ac_eacp_msg_acip_add(cvmx_wqe_t *work, ac_eacp_header_t *rqst, ac_eacp_header_t *rspd);
int ac_eacp_msg_dplane_rst(cvmx_wqe_t *work, ac_eacp_header_t *rqst, ac_eacp_header_t *rspd);
#endif
