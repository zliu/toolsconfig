#include <cvmx-wqe.h>
#include "ac_eacp_processor.h"

#define AC_EACP_RESPOND_CREATE(request, respond)\
do {\
    memset(respond, 0, sizeof(ac_eacp_header_t));\
    respond->preamble = AC_EACP_PREAMBLE;\
    respond->sequence = request->sequence;\
    respond->msg_class = request->msg_class;\
    respond->A = 1;\
    respond->msg_type = request->msg_type;\
} while(0)

int ac_eacp_msg_dplane_rst(cvmx_wqe_t *work, ac_eacp_header_t *rqst, ac_eacp_header_t *rspd)
{
    AC_EACP_RESPOND_CREATE(rqst, rspd);
    ac_eacp_payload_ack_t *result = (ac_eacp_payload_ack_t *) &rspd->payload;
    *result = 0;
    return 0;
}

int ac_eacp_msg_acip_add(cvmx_wqe_t *work, ac_eacp_header_t *rqst, ac_eacp_header_t *rspd)
{
    AC_EACP_RESPOND_CREATE(rqst, rspd);
    return 0;
}

int ac_eacp_processor(cvmx_wqe_t *work, uint8_t eacp_offset, ac_eacp_header_t *respond)
{
    ac_eacp_header_t *hdr = (ac_eacp_header_t *)(work->packet_data + eacp_offset);
    if (hdr->preamble != AC_EACP_PREAMBLE || hdr->A){
        return -1;
    }
    switch(hdr->msg_type)
    {
        case EACP_MSG_T_DPLANE_RST:
        ;
        break;

        case EACP_MSG_T_ACIP_ADD:
        ;
        break;

        default:
        break;
    }
    return 0;
}
