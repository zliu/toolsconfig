/***********************license start************************************
 * OCTEON SDK
 * 
 * Copyright (c) 2003-2005 Cavium Networks. All rights reserved.
 * 
 * This file, which is part of the OCTEON SDK from Cavium Networks,
 * contains proprietary and confidential information of Cavium Networks and
 * its suppliers.
 * 
 * Any licensed reproduction, distribution, modification, or other use of
 * this file or the confidential information or patented inventions
 * embodied in this file is subject to your license agreement with Cavium
 * Networks. Unless you and Cavium Networks have agreed otherwise in
 * writing, the applicable license terms can be found at:
 * licenses/cavium-license-type2.txt
 * 
 * All other use and disclosure is prohibited.
 * 
 * Contact Cavium Networks at info@caviumnetworks.com for more information.
 **********************license end**************************************/

/*
 * File version info: $Id: passthrough.c 39253 2008-12-05 18:22:15Z cchavva $
 *
 */

#include <stdio.h>
#include <string.h>

#include "cvmx-config.h"
#include "cvmx.h"
#include "cvmx-spinlock.h"
#include "cvmx-fpa.h"
#include "cvmx-pip.h"
#include "cvmx-ciu.h"
#include "cvmx-ipd.h"
#include "cvmx-pko.h"
#include "cvmx-dfa.h"
#include "cvmx-pow.h"
#include "cvmx-gmx.h"
#include "cvmx-asx.h"
#include "cvmx-sysinfo.h"
#include "cvmx-coremask.h"
#include "cvmx-bootmem.h"
#include "cvmx-helper.h"

#define QUEUES_PER_PORT 1
#define FAU_PACKETS     ((cvmx_fau_reg_64_t)(CVMX_FAU_REG_AVAIL_BASE + 0))   /**< Fetch and add for counting packets processed */
#define FAU_ERRORS      ((cvmx_fau_reg_64_t)(CVMX_FAU_REG_AVAIL_BASE + 8))   /**< Fetch and add for counting detected errors */
#define FAU_OUTSTANDING ((cvmx_fau_reg_64_t)(CVMX_FAU_REG_AVAIL_BASE + 16))  /**< Fetch and add for counting outstanding packets */

static CVMX_SHARED uint64_t start_cycle;
static CVMX_SHARED uint64_t stop_cycle;
static unsigned int packet_termination_num;


/* Note: The dump_packet routine that used to be here has been moved to
    cvmx_helper_dump_packet. */
//#define DUMP_PACKETS 1
//#define SWAP_MAC_ADDR  

#ifdef SWAP_MAC_ADDR
static inline void 
swap_mac_addr(uint64_t pkt_ptr)
{
    uint16_t s;
    uint32_t w;

    /* assuming an IP/IPV6 pkt i.e. L2 header is 2 byte aligned, 4 byte non-aligned */
    s = *(uint16_t*)pkt_ptr;
    w = *(uint32_t*)(pkt_ptr+2);
    *(uint16_t*)pkt_ptr = *(uint16_t*)(pkt_ptr+6);
    *(uint32_t*)(pkt_ptr+2) = *(uint32_t*)(pkt_ptr+8);
    *(uint16_t*)(pkt_ptr+6) = s;
    *(uint32_t*)(pkt_ptr+8) = w;
}
#endif

/**
 * Setup the Cavium Simple Executive Libraries using defaults
 *
 * @param num_packet_buffers
 *               Number of outstanding packets to support
 * @return Zero on success
 */
static int application_init_simple_exec(int num_packet_buffers)
{
    if (cvmx_helper_initialize_fpa(num_packet_buffers, num_packet_buffers, CVMX_PKO_MAX_OUTPUT_QUEUES * 4, 0, 0))
        return -1;

    if (!cvmx_octeon_is_pass1())
    {
        /* Don't enable RED for Pass 1 due to errata */
        if (cvmx_sysinfo_get()->board_type != CVMX_BOARD_TYPE_SIM)
            cvmx_helper_setup_red(num_packet_buffers/4, num_packet_buffers/8);
    }

    if (octeon_has_feature(OCTEON_FEATURE_NO_WPTR))
    {
        cvmx_ipd_ctl_status_t ipd_ctl_status;
        printf("Enabling CVMX_IPD_CTL_STATUS[NO_WPTR]\n");
        ipd_ctl_status.u64 = cvmx_read_csr(CVMX_IPD_CTL_STATUS);
        ipd_ctl_status.s.no_wptr = 1;
        cvmx_write_csr(CVMX_IPD_CTL_STATUS, ipd_ctl_status.u64);
    }

    int result = cvmx_helper_initialize_packet_io_global();

    if (!cvmx_octeon_is_pass1())
    {
        /* Leave 16 bytes space for the ethernet header */
        cvmx_write_csr(CVMX_PIP_IP_OFFSET, 2);
        int port, interface;
        /* Enable storing short packets only in the WQE */
        for (interface = 0; interface < 2; interface++)
        {
           /* Set the frame max size and jabber size to 65535, as the defaults
              are too small. */
           cvmx_helper_interface_mode_t imode = cvmx_helper_interface_get_mode(interface);
           int num_ports = cvmx_helper_ports_on_interface(interface);

           switch (imode)
           {
		case CVMX_HELPER_INTERFACE_MODE_SGMII:
		case CVMX_HELPER_INTERFACE_MODE_XAUI:
                   for (port=0; port < num_ports; port++)
                       cvmx_write_csr(CVMX_GMXX_RXX_JABBER(port,interface), 65535);
                   break;

		case CVMX_HELPER_INTERFACE_MODE_RGMII:
		case CVMX_HELPER_INTERFACE_MODE_GMII:
                   for (port=0; port < num_ports; port++)
                   {
                       cvmx_write_csr(CVMX_GMXX_RXX_FRM_MAX(port,interface), 65535);
                       cvmx_write_csr(CVMX_GMXX_RXX_JABBER(port,interface), 65535);
                   }
                   break;
               default:
                   break;
           }

            for (port=0; port < num_ports; port++)
            {
                cvmx_pip_port_cfg_t port_cfg;
                port_cfg.u64 = cvmx_read_csr(CVMX_PIP_PRT_CFGX(port + interface*16));
                port_cfg.s.dyn_rs = 1;
                cvmx_write_csr(CVMX_PIP_PRT_CFGX(port + interface*16), port_cfg.u64);
            }
        }
    }

    
    /* Initialize the FAU registers. */
    cvmx_fau_atomic_write64(FAU_ERRORS, 0);
    if (cvmx_sysinfo_get()->board_type == CVMX_BOARD_TYPE_SIM)
    {
        cvmx_fau_atomic_write64(FAU_PACKETS, 0);
        cvmx_fau_atomic_write64(FAU_OUTSTANDING, 0);
    }

    return result;
}

/**
 * Clean up and properly shutdown the simple exec libraries.
 *
 * @return Zero on success. Non zero means some resources are
 *         unaccounted for. In this case error messages will have
 *         been displayed during shutdown.
 */
static int application_shutdown_simple_exec(void)
{
    int result = 0;
    int status;
    int pool;

    cvmx_pko_shutdown();

    for (pool=0; pool<CVMX_FPA_NUM_POOLS; pool++)
    {
        if (cvmx_fpa_get_block_size(pool) > 0)
        {
            status = cvmx_fpa_shutdown_pool(pool);

            /* Special check to allow PIP to lose packets due to hardware prefetch */
            if ((pool == CVMX_FPA_PACKET_POOL) && (status > 0) && (status < CVMX_PIP_NUM_INPUT_PORTS))
                status = 0;

            result |= status;
        }
    }

    return result;
}


/**
 * Process incoming packets. Just send them back out the
 * same interface.
 *
 */
static void application_main_loop(void)
{
    cvmx_wqe_t *    work;
    uint64_t        port;
    cvmx_buf_ptr_t  packet_ptr;
    cvmx_pko_command_word0_t pko_command;
    const int use_ipd_no_wptr = octeon_has_feature(OCTEON_FEATURE_NO_WPTR);


    /* Build a PKO pointer to this packet */
    pko_command.u64 = 0;
    if (cvmx_sysinfo_get()->board_type == CVMX_BOARD_TYPE_SIM)
    {
       pko_command.s.size0 = CVMX_FAU_OP_SIZE_64;
       pko_command.s.subone0 = 1;
       pko_command.s.reg0 = FAU_OUTSTANDING;
    }

    while (1)
    {

        /* get the next packet/work to process from the POW unit. */
        if (cvmx_sysinfo_get()->board_type == CVMX_BOARD_TYPE_SIM)
        {
           work = cvmx_pow_work_request_sync(CVMX_POW_NO_WAIT);
           if (work == NULL) {
               if (cvmx_fau_fetch_and_add64(FAU_PACKETS, 0) == packet_termination_num)
                   break;
               continue;
           }
        }
    	else 
    	{
           work = cvmx_pow_work_request_sync(CVMX_POW_WAIT);
           if (work == NULL) {
               continue;
           }
	    }

        /* Errata PKI-100 fix. We need to fix chain pointers on segmneted
            packets. Although the size is also wrong on a single buffer packet,
            PKO doesn't care so we ignore it */
        if (cvmx_unlikely(work->word2.s.bufs > 1))
            cvmx_helper_fix_ipd_packet_chain(work);

        /* Check for errored packets, and drop.  If sender does not respond
        ** to backpressure or backpressure is not sent, packets may be truncated if
        ** the GMX fifo overflows. We ignore the CVMX_PIP_OVER_ERR error so we
        ** can support jumbo frames */
        if (cvmx_unlikely(work->word2.snoip.rcv_error) && (work->word2.snoip.err_code != CVMX_PIP_OVER_ERR))
        {
            /* Work has error, so drop */
            cvmx_helper_free_packet_data(work);
            if (use_ipd_no_wptr)
                cvmx_fpa_free(work, CVMX_FPA_PACKET_POOL, 0);
            else
                cvmx_fpa_free(work, CVMX_FPA_WQE_POOL, 0);
            continue;
        }

        /*
         * Insert packet processing here.
         *
         * Define DUMP_PACKETS to dump packets to the console.
         * Note that due to multiple cores executing in parallel, the output
         * will likely be interleaved.
         *
         */
        #ifdef DUMP_PACKETS
            printf("Processing packet\n");
            cvmx_helper_dump_packet(work);
        #endif

        /*
         * Begin packet output by requesting a tag switch to atomic.
         * Writing to a packet output queue must be synchronized across cores.
         *
         */
        port = work->ipprt;
        int queue = cvmx_pko_get_base_queue(port);
        cvmx_pko_send_packet_prepare(port, queue, CVMX_PKO_LOCK_ATOMIC_TAG);

	if (cvmx_sysinfo_get()->board_type == CVMX_BOARD_TYPE_SIM)
	{
           /* Increment the total packet counts */
           cvmx_fau_atomic_add64(FAU_PACKETS, 1);
           cvmx_fau_atomic_add64(FAU_OUTSTANDING, 1);
	}

	#ifdef SWAP_MAC_ADDR
	int is_ip = !work->word2.s.not_IP;
	#endif

        /* Build a PKO pointer to this packet */
        if (work->word2.s.bufs == 0)
        {
            /* Packet is entirely in the WQE. Give the WQE to PKO and have it
                free it */
            pko_command.s.total_bytes = work->len;
            pko_command.s.segs = 1;
            packet_ptr.u64 = 0;
            if (use_ipd_no_wptr)
            {
                packet_ptr.s.pool = CVMX_FPA_PACKET_POOL;
                packet_ptr.s.size = CVMX_FPA_PACKET_POOL_SIZE;
            }
            else
            {
                packet_ptr.s.pool = CVMX_FPA_WQE_POOL;
                packet_ptr.s.size = CVMX_FPA_WQE_POOL_SIZE;
            }
            packet_ptr.s.addr = cvmx_ptr_to_phys(work->packet_data);
            if (cvmx_likely(!work->word2.s.not_IP))
            {
                /* The beginning of the packet moves for IP packets */
                if (work->word2.s.is_v6)
                    packet_ptr.s.addr += 2;
                else
                    packet_ptr.s.addr += 6;
            }
        }
        else
        {
            pko_command.s.total_bytes = work->len;
            pko_command.s.segs = work->word2.s.bufs;
            packet_ptr = work->packet_ptr;
            if (!use_ipd_no_wptr)
                cvmx_fpa_free(work, CVMX_FPA_WQE_POOL, 0);
        }

        #ifdef SWAP_MAC_ADDR
        if (is_ip) 
            swap_mac_addr((uint64_t)cvmx_phys_to_ptr((uint64_t)packet_ptr.s.addr));
        #endif

        /*
         * Send the packet and wait for the tag switch to complete before
         * accessing the output queue. This ensures the locking required
         * for the queue.
         *
         */
        if (cvmx_pko_send_packet_finish(port, queue, pko_command, packet_ptr, CVMX_PKO_LOCK_ATOMIC_TAG))
        {
            printf("Failed to send packet using cvmx_pko_send_packet_finish\n");
            cvmx_fau_atomic_add64(FAU_ERRORS, 1);
        }
    }
}



/**
 * Determine if a number is approximately equal to a match
 * value. Checks if the supplied value is within 5% of the
 * expected value.
 *
 * @param value    Value to check
 * @param expected Value needs to be within 5% of this value.
 * @return Non zero if the value is out of range.
 */
static int cycle_out_of_range(float value, float expected)
{
    uint64_t range = expected / 5; /* 5% */
    if (range<1)
        range = 1;

    /* The expected time check is disabled for Linux right now. Since the
        Linux kernel is configured for a 6 Mhz clock, there are a couple
        of context switch during this test. On the real chip the clock will
        be set the real value (600 Mhz) alleviating this problem. */
#ifndef __linux__
    return ((value < expected - range) || (value > expected + range));
#else
    return 0;
#endif
}


/**
 * Perform application specific shutdown
 *
 * @param num_processors
 *               The number of processors available.
 */
static void application_shutdown(int num_processors)
{
    uint64_t run_cycles = stop_cycle - start_cycle;
    float cycles_packet;

    /* The following speed checks assume you are using the original test data
        and executing with debug turned off. */
    const float * expected_cycles;
    const float cn3xxx_cycles[16] = {244.0, 123.0, 90.0, 63.0, 55.0, 47.0, 42.0, 39.0, 38.0, 38.0, 38.0, 38.0, 38.0, 38.0, 38.0, 38.0};
    const float cn3020_cycles[2] = {272.0, 150.0};
    const float cn50xx_cycles[2] = {282.0, 156.0};
    const float cn3010_cycles[1] = {272.0};
    const float cn3005_cycles[1] = {315.0};
 
    if (OCTEON_IS_MODEL(OCTEON_CN3005))
        expected_cycles = cn3005_cycles;
    else if (OCTEON_IS_MODEL(OCTEON_CN3020))
        expected_cycles = cn3020_cycles;
    else if (OCTEON_IS_MODEL(OCTEON_CN30XX))
        expected_cycles = cn3010_cycles;
    else if (OCTEON_IS_MODEL(OCTEON_CN50XX))
        expected_cycles = cn50xx_cycles;
    else
        expected_cycles = cn3xxx_cycles;

    /* Display a rough calculation for the cycles/packet. If you need
        accurate results, run lots of packets. */
    uint64_t count = cvmx_fau_fetch_and_add64(FAU_PACKETS, 0);
    cycles_packet = run_cycles / (float)count;
    printf("Total %lld packets in %lld cycles (%2.2f cycles/packet)[expected %2.2f cycles/packet]\n",
           (unsigned long long)count, (unsigned long long)run_cycles, cycles_packet, expected_cycles[num_processors-1]);


    if (cycle_out_of_range(cycles_packet, expected_cycles[num_processors-1]))
    {
        printf("Expected cycles/packet check failed! expected: %2.2f, measured: %2.2f\n", expected_cycles[num_processors-1], cycles_packet);
        printf("TEST FAILED\n");
    }

    /* Display the results if a failure was detected. */
    if (cvmx_fau_fetch_and_add64(FAU_ERRORS, 0))
    {
        printf("Errors detected. TEST FAILED\n");
    }

    /* Wait for PKO to complete */
    printf("Waiting for packet output to finish\n");
    while (cvmx_fau_fetch_and_add64(FAU_OUTSTANDING, 0) != 0)
    {
        /* Spinning again */
    }

    /* Delay so the last few packets make it out. The fetch and add
        is a little ahead of the hardware */
    cvmx_wait(1000000);
}

/**
 * Main entry point
 *
 * @return exit code
 */
int main(int argc, char *argv[])
{
    cvmx_sysinfo_t *sysinfo;
    unsigned int coremask_passthrough;
    int result = 0;

    cvmx_user_app_init();

    /* compute coremask_passthrough on all cores for the first barrier sync below */
    sysinfo = cvmx_sysinfo_get();
    coremask_passthrough = sysinfo->core_mask;

    if (cvmx_sysinfo_get()->board_type == CVMX_BOARD_TYPE_SIM)
    {
        if (OCTEON_IS_MODEL(OCTEON_CN3005))
            packet_termination_num = 3032;
        else if (OCTEON_IS_MODEL(OCTEON_CN31XX) || OCTEON_IS_MODEL(OCTEON_CN3010) || OCTEON_IS_MODEL(OCTEON_CN50XX))
            packet_termination_num = 4548;
        else
            packet_termination_num = 6064;
    }
    else
       packet_termination_num = 1000;

    /*
     * elect a core to perform boot initializations, as only one core needs to
     * perform this function.
     *
     */
    if (cvmx_coremask_first_core(coremask_passthrough)) {
        printf("Version: %s\n", cvmx_helper_get_version());
        if ((result = application_init_simple_exec(packet_termination_num+64)) != 0) {
            printf("Simple Executive initialization failed.\n");
            printf("TEST FAILED\n");
            return result;
        }
    }
    cvmx_coremask_barrier_sync(coremask_passthrough);


    cvmx_helper_initialize_packet_io_local();

    /* Remember when we started the test.  For accurate numbers it needs to be as
       close as possible to the running of the application main loop. */
    if (cvmx_coremask_first_core(coremask_passthrough)) {
        if (cvmx_sysinfo_get()->board_type == CVMX_BOARD_TYPE_SIM)
        {
            cvmx_pow_iq_com_cnt_t pow_iq_com_cnt;
            printf("Waiting to give packet input (~1Gbps) time to read the packets...\n");
            do
            {
                pow_iq_com_cnt.u64 = cvmx_read_csr(CVMX_POW_IQ_COM_CNT);
            } while (pow_iq_com_cnt.s.iq_cnt < packet_termination_num);
            printf("Done waiting\n");
        }

        start_cycle = cvmx_get_cycle();
    }
    cvmx_coremask_barrier_sync(coremask_passthrough);

    application_main_loop();

    cvmx_coremask_barrier_sync(coremask_passthrough);

    /* Remember when we stopped the test. This could have been done in the
       application_shutdown, but for accurate numbers it needs to be as close as
       possible to the running of the application main loop. */
    if (cvmx_coremask_first_core(coremask_passthrough)) {

        stop_cycle = cvmx_get_cycle();
    }
    cvmx_coremask_barrier_sync(coremask_passthrough);

#if CVMX_PKO_USE_FAU_FOR_OUTPUT_QUEUES
    /* Free the prefetched output queue buffer if allocated */
    {
        void * buf_ptr = cvmx_phys_to_ptr(cvmx_scratch_read64(CVMX_SCR_OQ_BUF_PRE_ALLOC));
        if (buf_ptr)
            cvmx_fpa_free(buf_ptr, CVMX_FPA_OUTPUT_BUFFER_POOL, 0);
    }
#endif

    /* use core 0 to perform application shutdown as well. */
    if (cvmx_sysinfo_get()->board_type == CVMX_BOARD_TYPE_SIM && cvmx_coremask_first_core(coremask_passthrough))
    {

        int num_processors;
        CVMX_POP(num_processors, coremask_passthrough);
        application_shutdown(num_processors);

        if ((result = application_shutdown_simple_exec()) != 0) {
            printf("Simple Executive shutdown failed.\n");
            printf("TEST FAILED\n");
        }
    }

    cvmx_coremask_barrier_sync(coremask_passthrough);

    return result;
}
