/**
 * Setup the Cavium Simple Executive Libraries using defaults
 *
 * @param num_packet_buffers
 *               Number of outstanding packets to support
 * @return Zero on success
 */
static int application_init_simple_exec(int num_packet_buffers)
{
    if (cvmx_helper_initialize_fpa(num_packet_buffers, num_packet_buffers, CVMX_PKO_MAX_OUTPUT_QUEUES * 4, 0, 0))
        return -1;

    if (!cvmx_octeon_is_pass1())
    {
        /* Don't enable RED for Pass 1 due to errata */
        if (cvmx_sysinfo_get()->board_type != CVMX_BOARD_TYPE_SIM)
            cvmx_helper_setup_red(num_packet_buffers/4, num_packet_buffers/8);
    }

    if (octeon_has_feature(OCTEON_FEATURE_NO_WPTR))
    {
        cvmx_ipd_ctl_status_t ipd_ctl_status;
        printf("Enabling CVMX_IPD_CTL_STATUS[NO_WPTR]\n");
        ipd_ctl_status.u64 = cvmx_read_csr(CVMX_IPD_CTL_STATUS);
        ipd_ctl_status.s.no_wptr = 1;
        cvmx_write_csr(CVMX_IPD_CTL_STATUS, ipd_ctl_status.u64);
    }

    int result = cvmx_helper_initialize_packet_io_global();

    if (!cvmx_octeon_is_pass1())
    {
        /* Leave 16 bytes space for the ethernet header */
        cvmx_write_csr(CVMX_PIP_IP_OFFSET, 2);
        int port, interface;
        /* Enable storing short packets only in the WQE */
        for (interface = 0; interface < 2; interface++)
        {
           /* Set the frame max size and jabber size to 65535, as the defaults
              are too small. */
           cvmx_helper_interface_mode_t imode = cvmx_helper_interface_get_mode(interface);
           int num_ports = cvmx_helper_ports_on_interface(interface);

           switch (imode)
           {
		case CVMX_HELPER_INTERFACE_MODE_SGMII:
		case CVMX_HELPER_INTERFACE_MODE_XAUI:
                   for (port=0; port < num_ports; port++)
                       cvmx_write_csr(CVMX_GMXX_RXX_JABBER(port,interface), 65535);
                   break;

		case CVMX_HELPER_INTERFACE_MODE_RGMII:
		case CVMX_HELPER_INTERFACE_MODE_GMII:
                   for (port=0; port < num_ports; port++)
                   {
                       cvmx_write_csr(CVMX_GMXX_RXX_FRM_MAX(port,interface), 65535);
                       cvmx_write_csr(CVMX_GMXX_RXX_JABBER(port,interface), 65535);
                   }
                   break;
               default:
                   break;
           }

            for (port=0; port < num_ports; port++)
            {
                cvmx_pip_port_cfg_t port_cfg;
                port_cfg.u64 = cvmx_read_csr(CVMX_PIP_PRT_CFGX(port + interface*16));
                port_cfg.s.dyn_rs = 1;
                cvmx_write_csr(CVMX_PIP_PRT_CFGX(port + interface*16), port_cfg.u64);
            }
        }
    }

    
    /* Initialize the FAU registers. */
    cvmx_fau_atomic_write64(FAU_ERRORS, 0);
    if (cvmx_sysinfo_get()->board_type == CVMX_BOARD_TYPE_SIM)
    {
        cvmx_fau_atomic_write64(FAU_PACKETS, 0);
        cvmx_fau_atomic_write64(FAU_OUTSTANDING, 0);
    }

    return result;
}


int ewx_board_init()
{
    cvmx_sysinfo_t *sysinfo;
    unsigned int coremask_se;
    int result = 0;
    
    cvmx_user_app_init();

	int i;
	uint16_t ipd_group;

    /* compute coremask_passthrough on all cores for the first barrier sync below */
    sysinfo = cvmx_sysinfo_get();
    coremask_se = sysinfo->core_mask;
/*
    if (cvmx_sysinfo_get()->board_type == CVMX_BOARD_TYPE_SIM)
    {
        if (OCTEON_IS_MODEL(OCTEON_CN3005))
            packet_termination_num = 3032;
        else if (OCTEON_IS_MODEL(OCTEON_CN31XX) || OCTEON_IS_MODEL(OCTEON_CN3010) || OCTEON_IS_MODEL(OCTEON_CN50XX))
            packet_termination_num = 4548;
        else
			packet_termination_num = 6064;
    }
    else
       packet_termination_num = 1000;
*/

    /*
     * elect a core to perform boot initializations, as only one core needs to
     * perform this function.
     *
     */
    if (cvmx_coremask_first_core(coremask_se)) {
        printf("Version: %s\n", cvmx_helper_get_version());
		if (!(coremask_se & 1)) {
			/*there is another SE or linux, so we skip the io_global init, just as linux-filter*/
			printf("waiting for ipd status\n");
			cvmx_ipd_ctl_status_t ipd_reg;
			do
			{
				ipd_reg.u64 = cvmx_read_csr(CVMX_IPD_CTL_STATUS);
			} while (!ipd_reg.s.ipd_en);
			g_var.linux_running = 1;
			//cvmx_helper_initialize_packet_io_global();
#if CVMX_PKO_USE_FAU_FOR_OUTPUT_QUEUES
			//cvmx_helper_initialize_packet_io_global();
#error Linux-filter cannot be built with CVMX_PKO_USE_FAU_FOR_OUTPUT_QUEUES
#else
			/* We need to call cvmx_cmd_queue_initialize() to get the pointer to
			   the named block. The queues are already setup by the ethernet
			   driver, so we don't actually need to setup a queue. Pass some
			   invalid parameters to cause the queue setup to fail */
			cvmx_cmd_queue_initialize(0, 0, -1, 0);

			for (i=0; i<cvmx_helper_get_number_of_interfaces(); i++) {
				cvmx_helper_interface_probe(i);
			}

#endif
		} else if ((result = application_init_simple_exec(packet_termination_num+64)) != 0) {
            printf("Simple Executive initialization failed.\n");
            printf("TEST FAILED\n");
            return result;
        }
    }
    cvmx_coremask_barrier_sync(coremask_passthrough);

	if (g_var.linux_running) {
		/*There must be another core run the init function, we should mask off the to_linux_group*/
		cvmx_pow_set_group_mask(cvmx_get_core_num(), (1<<FROM_LINUX_GROUP) | (1<<FROM_INPUT_PORT_GROUP));
		ipd_group = FROM_INPUT_PORT_GROUP;
	} else {
		cvmx_pow_set_group_mask(cvmx_get_core_num(), 1<<TO_LINUX_GROUP);
		ipd_group = TO_LINUX_GROUP;
	}
	g_param.ipd_group = ipd_group;
    cvmx_helper_initialize_packet_io_local();

    /* Remember when we started the test.  For accurate numbers it needs to be as
       close as possible to the running of the application main loop. */
    if (cvmx_coremask_first_core(coremask_passthrough)) {
		/*just for temp use, need to be fixed*/
		if (sysinfo->board_type == CVMX_BOARD_TYPE_CUST_PA6341) {
			cvmx_write_csr( CVMX_LED_CLK_PHASE, 0x7full );
			cvmx_write_csr( CVMX_LED_BLINK, 0xffull );
			cvmx_write_csr( CVMX_LED_PRT_FMT, 0x05ull );
			cvmx_write_csr( CVMX_LED_PRT, 0xf0ull );
			cvmx_write_csr( CVMX_LED_UDD_CNTX(0), 0x03ull );
			cvmx_write_csr( CVMX_LED_UDD_DATX(0), 0x01ull );
			cvmx_write_csr( CVMX_LED_EN, 0x01ull );
		}
		init_default_ipd_group_mask(ipd_group);
		if(g_var.linux_running){
			printf("Done waiting\n");
#ifdef CVMX_PKO_LOCKLESS_OPERATION
			int i;
			cvmx_pko_initialize_global();
			for (i=0; i<2; i++) {
				__cvmx_helper_interface_setup_pko(i);
			}
#endif
		}else{
			cvmx_helper_ipd_and_packet_input_enable();
		}
		init_global_port_map(&g_param);

		for(i=0; valid_phys_port(i); i++){
			int ipd_port = get_ipd_port_from_phys_port(i);
			set_work_mode(i, g_var.port_map[ipd_port].work_mode);
		}

        start_cycle = cvmx_get_cycle();
	}
    cvmx_coremask_barrier_sync(coremask_passthrough);
}


