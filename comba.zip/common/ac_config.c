/** 
* @file ac_config.c
* @brief 本文件存放AC的全局配置操作函数
* @author zliu
* @version 0.0.1
* @date 2010-05-12
*/
#include <ac_config.h>
#include <ac_util.h>

#define DETAILED_DEBUG 1

int ac_config_init()
{
    g_ac_parameter.internal_ip = AC_DEFAULT_PARAMETER_INTERNAL_IP;
    g_ac_parameter.external_ip_table.count = 1;
    g_ac_parameter.external_ip_table.table[0] = AC_DEFAULT_PARAMETER_EXTERNAL_IP;
    return 0;
}

/** 
 * @brief AC外部IP表插入; Insert new IP to AC external IP table
 * 
 * @param ip 新增IP; New IP
 * 
 * @return 0 成功; Successful
 *        -1 失败
 */
int ac_config_external_ip_array_add(uint32_t ip)
{
    int i;
#if DETAILED_DEBUG  
    printf("AC External IPs :\n");
#endif
    for (i = 0; i < g_ac_parameter.external_ip_table.count; i++) {
#if DETAILED_DEBUG
        uint32_t ex_ip = g_ac_parameter.external_ip_table.table[i];
        printf("%u:%u:%u:%u\n", ex_ip >> 24, (ex_ip >> 16) & 0xff, (ex_ip >> 8) & 0xff, (ex_ip) & 0xff);
#endif
        if (g_ac_parameter.external_ip_table.table[i] == ip) {
#if DETAILED_DEBUG
            printf("Hit\n");
#endif
            return 0;
        }
    }
    if (g_ac_parameter.external_ip_table.count < AC_EXTERNAL_IP_ARRAY_SIZE) {
        printf("Error: Too many external IP for AC\n");
        return -1;
    }
    g_ac_parameter.external_ip_table.table[g_ac_parameter.external_ip_table.count++] = ip;
    return 0;
}

int ac_config_external_ip_array_search(uint32_t ip)
{
    int i;
    for (i = 0; i < g_ac_parameter.external_ip_table.count; i++) {
        if (ip == g_ac_parameter.external_ip_table.table[i]) {
            return 1;
        }
    }
    return 0;
}

int ac_config_external_ip_array_del(uint32_t ip)
{
    int i;
    for (i = 0; i < g_ac_parameter.external_ip_table.count; i++) {
        if (ip == g_ac_parameter.external_ip_table.table[i]) {
            if ((g_ac_parameter.external_ip_table.count != 1) && 
                (g_ac_parameter.external_ip_table.count != (i + 1))) {
                g_ac_parameter.external_ip_table.table[i] = 
                    g_ac_parameter.external_ip_table.table[g_ac_parameter.external_ip_table.count - 1];
            }
            g_ac_parameter.external_ip_table.count--;
            return 1;
        }
    }
    return 0;
}
