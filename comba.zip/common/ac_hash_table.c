/** 
 * @file ac_hashtable.c
 * @brief 本文件存放hash表相关操作函数
 * @author zliu
 * @version 0.0.1
 * @date 2010-05-12
 */
#include <ac_hash_table.h>

static int32_t ac_ip_table_insert_cb(void *this, void *user_data, void *table_item)
{
    memcpy(table_item, this, sizeof(ac_ip_table_item_t));
    return 1;
}

static int32_t ac_ip_table_compare_cb(void *this, void *user_data, void *table_item)
{
    if (((ac_ip_table_item_t *)table_item)->ip == ((ac_ip_table_item_t *)this)->ip)
        return 0;
    return 1;
}

static int32_t ac_ip_table_remove_cb(void *this, void *user_data, void *table_item)
{
    return 0;
}

static void ac_ip_table_bucket_alloc_cb(int size)
{
    return 0;
}

static int32_t ac_ip_table_bucket_free_cb(void *bucket_p)
{
    return 0;
}

static void ac_ip_table_show_cb(void *table_item)
{
    return 0;
}

ewx_hash_table_t *ac_ip_table_init(char *name, int bucket_num, int lock)
{
    return ewx_hash_table_init(name, bucket_num, AC_IP_TABLE_BUCKET_SIZE, sizeof(ac_ip_table_item_t), lock);
}

void *ac_ip_table_search(ewx_hash_table_t *iptable, ac_ip_table_item_t *item)
{
    uint32_t hash = ac_ip_hash(item->ip);
    return ewx_hash_table_search(iptable, hash, ac_ip_table_compare_cb, item);
}

uint32_t ac_ip_table_insert(ewx_hash_table_t *iptable, ac_ip_table_item_t *item)
{
    uint32_t hash = ac_ip_hash(item->ip);
    return ewx_hash_table_insert(iptable, hash, NULL, ac_ip_table_compare_cb, item, NULL, NULL, ac_hash_table_alloc_cb);
}

int32_t ac_ip_table_remove(ewx_hash_table_t *iptable, ac_ip_table_item_t *item)
{
    uint32_t hash = ac_ip_hash(item->ip);
    return ewx_hash_table_remove(iptable, hash, ac_ip_table_compare_cb, item, NULL, NULL, ac_ip_table_bucket_free_cb);
}

void ac_ip_table_show(ewx_hash_table_t *iptable)
{
    return ewx_hash_table_show(iptable, ac_ip_table_show_cb);
}
