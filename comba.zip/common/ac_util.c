/** 
* @file ac_util.c
* @brief 
* @author zliu
* @version 0.0.1
* @date 2010-05-12
*/
#include <ac_defs.h>
#include <ac_util.h>

inline void ac_swap_mac(void *src, void *dst)
{
    uint32_t hi;
    uint16_t lo;
    hi = *(uint32_t *)src;
    lo = *(uint16_t *)(src + 4);
    *(uint32_t *)src = *(uint32_t *)dst;
    *(uint16_t *)(src + 4) = *(uint16_t *)(dst + 4);
    *(uint32_t *)dst = hi;
    *(uint16_t *)(dst + 4) = lo;
}

inline void ac_copy_l2_hdr_with_vlan(void* src, void *dst, vlan_field)
{
    memcpy(dst, src, 14 + vlan_field * 4);
}

inline void ac_copy_l2_hdr(void* src, void *dst)
{
    ac_copy_l2_hdr_with_vlan(src, dst, 0);
}

inline void ac_copy_l2_hdr_with_vlan_swap_mac(void* src, void *dst, vlan_field)
{
    ac_copy_l2_hdr(src, dst, vlan_field);
    ac_swap_mac(dst, dst + 6);
}

inline void ac_copy_l2_hdr_swap_mac(void* src, void *dst)
{
    ac_copy_l2_hdr_with_vlan_swap_mac(src, dst, 0);
}

inline void ac_swap_ip(void *ip_hdr)
{
    uint32_t ip;
    ip = ((ac_ip_header_t *)ip_hdr)->src;
    ((ac_ip_header_t *)ip_hdr)->src = ((ac_ip_header_t *)ip_hdr)->dst;
    ((ac_ip_header_t *)ip_hdr)->dst = ip;
}

inline void ac_copy_ip_hdr(void* src, void *dst)
{
    memcpy(dst, src, ((ac_ip_header_t *)src)->IHL * 4);
}

inline void ac_copy_ip_hdr_swap_ip(void *src, void *dst)
{
    ac_copy_ip_hdr(src, dst);
    ac_swap_ip(dst);
}

inline void ac_eacp_msg_hdr_construct(void *pkt, void *rspd_pkt)
{
    ac_copy_l2_hdr_swap_mac(pkt, rspd_pkt);
    /* ac_copy_ip_hdr_swap_ip(pkt + 18, rspd_pkt + 14); */
    ac_ip_header_t *ip_rqst_ptr = pkt + L2_HEAD_NOVLAN_LEN;
    ac_ip_header_t *ip_ptr = rspd_pkt + L2_HEAD_NOVLAN_LEN;
    ip_ptr->version = ip_rqst_ptr->version;
    ip_ptr->IHL = 5;
    ip_ptr->TOS = 0;
    ip_ptr->len = 0;
    ip_ptr->id = ip_rqst_ptr->id + 1;
    ip_ptr->ip_flags = ip_rqst_ptr->ip_flags;
    ip_ptr->frag_offset = ip_rqst_ptr->frag_offset;
    ip_ptr->TTL = ip_rqst_ptr->TTL;
    ip_ptr->protocol = L4_UDP;
    ip_ptr->hdr_chksm = 0;
    ip_ptr->src = ip_rqst_ptr->dst;
    ip_ptr->dst = ip_rqst_ptr->src;
}
