#include <ewx_board_init.h>
#include <ewx/ewx_hash_table.h>
#include <ac_defs.h>
#include <ac_config.h>
#include <ac_packet_inspect.h>
#include <ac_packet_parse.h>
#include <ac_packet_process.h>
#include <ac_packet_forward.h>


ewx_hash_table_t *g_wtp_ip_table;
ewx_hash_table_t *g_sta_ip_table;

int ac_main_loop()
{
    cvmx_wqe_t *work;
    packet_info_t packet_info;
    ac_forward_command_t ac_forward_command;
        
    while (1)
    {
        /* get the next packet/work to process from the POW unit. */
        if (cvmx_sysinfo_get()->board_type == CVMX_BOARD_TYPE_SIM)
        {
           work = cvmx_pow_work_request_sync(CVMX_POW_NO_WAIT);
           if (work == NULL) {
               //if (cvmx_fau_fetch_and_add64(FAU_PACKETS, 0) == packet_termination_num)
                //   break;
               continue;
           }
        }
    	else 
    	{
           work = cvmx_pow_work_request_sync(CVMX_POW_WAIT);
           if (work == NULL) {
               continue;
           }
    	}

        /* Errata PKI-100 fix. We need to fix chain pointers on segmneted
            packets. Although the size is also wrong on a single buffer packet,
            PKO doesn't care so we ignore it */
        if (cvmx_unlikely(work->word2.s.bufs > 1))
            cvmx_helper_fix_ipd_packet_chain(work);

        /*
         * Insert packet processing here.
         *
         * Define DUMP_PACKETS to dump packets to the console.
         * Note that due to multiple cores executing in parallel, the output
         * will likely be interleaved.
         *
         */

            printf("Processing packet\n");
            cvmx_helper_dump_packet(work);

//        ac_packet_inspect(work, &packet_info);
//        ac_packet_parse(work, &packet_info);
//        ac_packet_process(work, &packet_info, &ac_forward_command);
        ac_forward_command.bufs = work->word2.s.bufs;
        ac_forward_command.len = work->len;
        ac_forward_command.packet_ptr = work->packet_ptr;
        ac_forward_command.port = work->ipprt;

        ac_packet_forward(&ac_forward_command);
    }
    return 0;
}

int main()
{
    ewx_board_init();
    ac_config_init();
    ac_main_loop();
    return 0;
}
