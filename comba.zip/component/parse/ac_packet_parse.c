#include <ac_util.h>
#include <ac_defs.h>

extern ac_parameter_t g_ac_parameter;

inline int ac_packet_parse(cvmx_wqe_t *work, packet_info_t *packet_info) 
{
    uint32_t dip;
    uint16_t sport, dport;
    uint8_t *udp_payload;
    if (!work->word2.s.not_IP) { /* IP */
        dip = *(uint32_t *)&work->packet_data[IP_OFFSET_IN_WORK_PACKET_DATA + 16]; // need check
        printf("dip = %u\n", dip);
        if (dip == g_ac_parameter.internal_ip) { /* From Linux */
            if (packet_info->is_udp) { /* UDP */
                udp_payload = &work->packet_data[IP_OFFSET_IN_WORK_PACKET_DATA + packet_info->udp_offset];
                sport = *(uint16_t *)udp_payload;
                dport = *(uint16_t *)(udp_payload + 2);
                printf("sport = %u\n", sport);
                printf("dport = %u\n", dport);
                if ((dport == g_ac_parameter.eacp.dport) && (sport == g_ac_parameter.eacp.sport)) { /* EACP */
                    packet_info->is_eacp = 1;
                    packet_info->eacp_offset = packet_info->udp_offset + 8;
                    packet_info->type = AC_PACKET_TYPE_EACP;
                } else { /* Not CAPWAP, Unknown packet from Linux -> Drop */
                    packet_info->type = AC_PACKET_TYPE_UNKNOWN_DROP;
                }
            } else { /* Not UDP, Unknown packet from Linux -> Drop */
                packet_info->type = AC_PACKET_TYPE_UNKNOWN_DROP;
            }
        } else if (ac_external_ip_table_search(dip) == 1) { /* To AC */
            if (packet_info->is_udp) { /* UDP */
                udp_payload = &work->packet_data[IP_OFFSET_IN_WORK_PACKET_DATA + packet_info->udp_offset];
                sport = *(uint16_t *)(udp_payload);
                dport = *(uint16_t *)(udp_payload + 2);
                printf("sport = %u\n", sport);
                printf("dport = %u\n", dport);
                if (dport == g_ac_parameter.capwap.ctrl_dport) { /* CAPWAP Control Packet -> Submit to Linux */
                                                                 /* Other Packet to AC -> Submit to Linux */
                    packet_info->type = AC_PACKET_TYPE_MAYBE_CAPWAP_CTL;
                } else if ((dport == g_ac_parameter.capwap.data_dport) && (sport == g_ac_parameter.capwap.data_sport)) { 
                    /* CAPWAP Data Packet */
                    if ((*(ac_capwap_header_t *)(udp_payload + 8)).k == 1) { /* CAPWAP Keep Alive Packet */
                        packet_info->is_capwap = 1;
                        packet_info->capwap_offset = packet_info->udp_offset + 8;
                        packet_info->type = AC_PACKET_TYPE_CAPWAP_KEEP_ALIVE;
                    } else { /* CAPWAP Data Packet with user data */
                        packet_info->is_capwap = 1;
                        packet_info->capwap_offset = packet_info->udp_offset + 8;
                        packet_info->type = AC_PACKET_TYPE_CAPWAP_DATA;
                    }
                } else { /* Not Capwap, Unknown packet -> Submit to Linux */
                    packet_info->type = AC_PACKET_TYPE_UNKNOWN_TO_LINUX;    
                }
            } else { /* not UDP packet -> Submit to Linux */
                packet_info->type = AC_PACKET_TYPE_UNKNOWN_TO_LINUX;
            }
        } else {
            packet_info->type = AC_PACKET_TYPE_UNKNOWN_TO_BCM;
        }
    } else if (work->word2.snoip.is_arp) { /* ARP */
        dip = *(uint32_t *)(&work->packet_data[38]);
        printf("target_ip = %u\n", dip);
        if (ac_external_ip_table_search(dip) == 1) { /* ARP for AC */
            if (*(uint16_t *)(&work->packet_data[20]) == 1) { /* request -> send a reply */
                packet_info->type = AC_PACKET_TYPE_ARP_REQ;
            } else { /* reply -> Submit to Linux */
                packet_info->type = AC_PACKET_TYPE_ARP_REP;
            }
        } else { /* ARP not for AC -> */
            packet_info->type = AC_PACKET_TYPE_UNKNOWN_TO_BCM;
        }
    } else { /* unknown L2 packet */
        packet_info->type = AC_PACKET_TYPE_UNKNOWN_TO_BCM;
    }
    return 0;
}
