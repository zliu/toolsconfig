#include <ac_defs.h>

int ac_packet_forward(ac_forward_command_t *forward_command)
{
   int port, queue;
    cvmx_pko_command_word0_t pko_command;
    cvmx_buf_ptr_t packet_ptr;

   if (forward_command->bufs != 0 ) {
        printf("forward work\n");
        port = forward_command->port;
        queue = cvmx_pko_get_base_queue(port);
        cvmx_pko_send_packet_prepare(port, queue, CVMX_PKO_LOCK_ATOMIC_TAG);

	    if (cvmx_sysinfo_get()->board_type == CVMX_BOARD_TYPE_SIM)
    	{
            /* Increment the total packet counts */
            cvmx_fau_atomic_add64(FAU_PACKETS, 1);
            cvmx_fau_atomic_add64(FAU_OUTSTANDING, 1);
	    }
        /* Build a PKO pointer to this packet */
        pko_command.s.total_bytes = forward_command->len;
        pko_command.s.segs = forward_command->bufs;
        packet_ptr = forward_command->packet_ptr;
        // cvmx_fpa_free(work, CVMX_FPA_WQE_POOL, 0);

        /*
         * Send the packet and wait for the tag switch to complete before
         * accessing the output queue. This ensures the locking required
         * for the queue.
         *
         */
        if (cvmx_pko_send_packet_finish(port, queue, pko_command, packet_ptr, CVMX_PKO_LOCK_ATOMIC_TAG))
        {
            printf("Failed to send packet using cvmx_pko_send_packet_finish\n");
            cvmx_fau_atomic_add64(FAU_ERRORS, 1);
            return -1;
        }
    }
    return 0;
}
