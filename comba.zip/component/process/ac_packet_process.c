#include <ac_defs.h>
#include <ac_eacp_processor.h>

inline int ac_packet_process(cvmx_wqe_t *work, packet_info_t *packet_info, ac_forward_command_t *forward_cmd)
{
    switch (packet_info->type) {
        case AC_PACKET_TYPE_EACP :
            ac_eacp_processor(work, packet_info->eacp_offset, forward_cmd);
            break;
        case AC_PACKET_TYPE_MAYBE_CAPWAP_CTL :
            break;
        case AC_PACKET_TYPE_CAPWAP_KEEP_ALIVE :
            break;
        case AC_PACKET_TYPE_CAPWAP_DATA :
            break;
        case AC_PACKET_TYPE_UNKNOWN_TO_BCM :
            break;
        case AC_PACKET_TYPE_UNKNOWN_TO_LINUX :
            break;
        case AC_PACKET_TYPE_UNKNOWN_DROP :
            break;
    }
    return 0;
}
