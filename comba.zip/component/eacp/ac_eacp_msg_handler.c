#include <ac_defs.h>
#include <ac_util.h>
#include <ac_eacp_msg_handler.h>
#include <ac_hash_table.h>
#include <ac_eacp_defs.h>

extern ewx_hash_table_t *g_wtp_ip_table;

int ac_eacp_msg_dplane_rst(cvmx_wqe_t *work, ac_eacp_pkt_t *rqst, ac_eacp_pkt_t *rspd)
{
    return 0;
}

int ac_eacp_msg_ac_addr_add(cvmx_wqe_t *work, ac_eacp_pkt_t *rqst, ac_eacp_pkt_t *rspd)
{
    return 0;
}

uint16_t ac_eacp_msg_wtp_add(void *payload, void *rspd_payload)
{
    int i, result = 0;
    //读取wtp数目
    ac_eacp_payload_wtp_info_t *wtp_ptr = (ac_eacp_payload_wtp_info_t*)payload;
    ac_eacp_payload_mac_ack_t *ack = (ac_eacp_payload_mac_ack_t *)rspd_payload;
    uint8_t count = wtp_ptr->count;
    //指针指向wtp信息数组头
    ac_eacp_wtp_info_t *wtps = wtp_ptr->wtpInfo;
    //去wtp索引表里搜索每一个ip
    ac_ip_table_item_t item;
    for (i = 0; i < count ; i++){
        item.ip = IP_TO_U32(wtps[i].ip_addr);
        item.index = 0;//ac_wtp_table_insert(wtps[i]);
        result = ac_ip_table_insert(g_wtp_ip_table, &item);
        if (result < 0)
            return result;
        ack->count ++;
#ifdef AC_EACP_LARGE_PAYLOAD
        ;
#endif
        ack->macResult[i].result = result;
        memcpy(ack->macResult[i].mac, wtps[i].mac_addr, 6);
    }
        //alloc space for respond pkt
        //place rspd into that space
        //create a work for sending back respond
    //有就更新，没有就加入
    return 0;
}
