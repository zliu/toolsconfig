#include <ac_defs.h>
#include <ac_eacp_msg_handler.h>

int ac_eacp_processor(cvmx_wqe_t *work, uint8_t eacp_offset, ac_forward_command_t *respond)
{
    int l2_hdr_len = 14;
    int ip_hdr_len = 20;
    int upd_hdr_len = 8;
    ac_eacp_pkt_t *msg_hdr = (ac_eacp_pkt_t *)(work->packet_data + eacp_offset);
    if (msg_hdr->hdr.preamble != AC_EACP_PREAMBLE){
        return -1;
    }
    void *rspd_pkt = cvmx_fpa_alloc(CVMX_FPA_PACKET_POOL);
    void *payload = msg_hdr->payload;
    void *rspd_payload = rspd_pkt + eacp_offset;
    void *pkt = (void *)(work->packet_data + WQE_PKTDATA_PAD);
    respond->packet_ptr.u64 = 0;
    respond->packet_ptr.s.pool = CVMX_FPA_PACKET_POOL;
    respond->packet_ptr.s.size = CVMX_FPA_PACKET_POOL_SIZE;
    respond->packet_ptr.s.addr = cvmx_ptr_to_phys(rspd_pkt);
    ac_eacp_pkt_t *rspd_msg_hdr = (ac_eacp_pkt_t *)(rspd_pkt + 14 + 20 + 8);

    switch(msg_hdr->hdr.msghdr.msgType)
    {
        case EACP_MSG_T_DPLANE_RST:
        ;
        break;

        case EACP_MSG_T_AC_ADDR_ADD:
        ;
        break;

        case EACP_MSG_T_AC_ADDR_DEL:
        ;
        break;

        case EACP_MSG_T_AC_ADDR_SEARCH:
        ;
        break;

        case EACP_MSG_T_CAPWAP_PORT_SET:
        ;
        break;

        case EACP_MSG_T_CAPWAP_PORT_GET:
        ;
        break;

        case EACP_MSG_T_JUMBO_SWITCH:
        ;
        break;

        case EACP_MSG_T_WTP_ADD:
        ac_eacp_msg_wtp_add(payload, rspd_payload, respond);
        break;

        case EACP_MSG_T_WTP_DEL:
        ;
        break;

        case EACP_MSG_T_WTP_DEL_ALL:
        ;
        break;

        case EACP_MSG_T_WTP_SEARCH_ALL:
        ;
        break;

        case EACP_MSG_T_WTP_SEARCH_RANGE:
        ;
        break;

        case EACP_MSG_T_WTP_SEARCH:
        ;
        break;

        case EACP_MSG_T_STA_ADD:
        ;
        break;

        case EACP_MSG_T_STA_DEL_ALL:
        ;
        break;

        case EACP_MSG_T_STA_DEL:
        ;
        break;

        case EACP_MSG_T_STA_SEARCH_ALL:
        ;
        break;
        
        case EACP_MSG_T_STA_SEARCH_RANGE:
        ;
        break;
        
        case EACP_MSG_T_STA_SEARCH:
        ;
        break;
        
        case EACP_MSG_T_ACL_WTP_ADD:
        ;
        break;

        case EACP_MSG_T_ACL_WTP_DEL_ALL:
        ;
        break;

        case EACP_MSG_T_ACL_WTP_DEL:
        ;
        break;

        case EACP_MSG_T_ACL_WTP_SEARCH_ALL:
        ;
        break;

        case EACP_MSG_T_ACL_WTP_SEARCH_RANGE:
        ;
        break;

        case EACP_MSG_T_ACL_WTP_SEARCH:
        ;
        break;

        case EACP_MSG_T_ACL_STA_ADD:
        ;
        break;

        case EACP_MSG_T_ACL_STA_DEL_ALL:
        ;
        break;

        case EACP_MSG_T_ACL_STA_DEL:
        ;
        break;

        case EACP_MSG_T_ACL_STA_SEARCH_ALL:
        ;
        break;

        case EACP_MSG_T_ACL_STA_SEARCH_RANGE:
        ;
        break;

        case EACP_MSG_T_ACL_STA_SEARCH:
        ;
        break;

        case EACP_MSG_T_ALARM_CPU_THRESHOLD_SET:
        ;
        break;

        case EACP_MSG_T_STAT_DPLANE_UPTIME_GET:
        ;
        break;

        case EACP_MSG_T_STAT_CPU_USAGE_GET:
        ;
        break;

        case EACP_MSG_T_STAT_PACKETS_COUNTERS_GET:
        ;
        break;

        default:
        break;
    }
    memcpy(rspd_msg_hdr, msg_hdr, EACP_HDR_LEN);
    ack_hdr->hdr.msghdr.msgType |= EACP_ACK_MSG;
    ac_eacp_msg_hdr_construct(pkt, rspd_pkt);
    return 0;
}
